<footer id="colophon" role="contentinfo" class="site-footer   footer-foreground" style="background:#fff;">
  <div class="footer-section  footer-foreground" >
    <div class="container">
	<!--widgets area-->
	<aside class="widget-area" role="complementary" aria-label="Footer">
			</aside><!-- .widget-area -->
	<div class="row">
      <div class="col-md-12">
        <center>
          <ul id="footer-social" class="header-social-icon animate fadeInRight" >
          </ul>
        </center>
      </div>
	  </div> 
	  <div class="row">	  
	  <div class="vertical-center footer-bottom-section">
		<!-- bottom footer -->
		<div class="col-md-6 site-info">
		  <p align="center" style="color:#fff;" > <a href="#"> www.askmee.in </a> </p>
		</div>
		<!-- end of bottom footer -->
		  <div class="col-md-12 bottom-menu">
			<center>         
				<div id="footer-menu" class="menu"><ul>
<li class="page_item page-item-29"><a href="index.html">Blog</a></li>
<li class="page_item page-item-7"><a href="page_id_7.html">Cart</a></li>
<li class="page_item page-item-8"><a href="index.html">Checkout</a></li>
<li class="page_item page-item-30 current_page_item"><a href="index.html" aria-current="page">Homepage</a></li>
<li class="page_item page-item-9"><a href="index.html">My account</a></li>
<li class="page_item page-item-2"><a href="index.html">Sample Page</a></li>
<li class="page_item page-item-6"><a href="index.html">Shop</a></li>
</ul></div>
			</center>
		  </div>
		</div>
	</div>			
	</div><!-- .container -->
  </div>
  <a id="scroll-btn" href="#" class="scroll-top"><i class="fa fa-angle-double-up"></i></a>
</footer>
<!-- #colophon -->
	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type='text/javascript' src='wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockui.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"index.html","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"http:\/\/askmee.in\/?page_id=7","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js'></script>
<script type='text/javascript' src='wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"index.html","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"index.html","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_7b058a617d9691594b85f4a078f20914","fragment_name":"wc_fragments_7b058a617d9691594b85f4a078f20914","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var newYorkBusinessScreenReaderText = {"quote":"<span class=\"fa icon fa-quote-right\" aria-hidden=\"true\" role=\"img\"> <use href=\"#icon-quote-right\" xlink:href=\"#icon-quote-right\"><\/use> <\/span>"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/themes/new-york-business/js/skip-link-focus-fix.js'></script>
<script type='text/javascript' src='wp-content/themes/new-york-business/js/bootstrap.min.js'></script>
<script type='text/javascript' src='wp-includes/js/wp-embed.min.js'></script>
</body>
</html>