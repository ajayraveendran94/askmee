<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>
<title></title>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<link rel="alternate" type="application/rss+xml" title=" &raquo; Feed" href="http://askmee.in/?feed=rss2" />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Comments Feed" href="http://askmee.in/?feed=comments-rss2" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"wp-includes/js/wp-emoji-release.min.js"}};
			/*! This file is auto-generated */
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>

<link rel='stylesheet' id='wp-block-library-css'  href='<?php echo base_url("assets/wp-includes/css/dist/block-library/style.min.css");?>' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='<?php echo base_url("assets/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css");?>' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-layout-css'  href='<?php echo base_url("assets/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css");?>' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='<?php echo base_url("assets/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css");?>' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='<?php echo base_url("assets/wp-content/plugins/woocommerce/assets/css/woocommerce.css");?>' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='easy-storefront-parent-styles-css'  href='<?php echo base_url("assets/wp-content/themes/new-york-business/style.css");?>' type='text/css' media='all' />
<link rel='stylesheet' id='easy-storefront-styles-css'  href='assets/wp-content/themes/easy-storefront/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='new-york-business-fonts-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A300%2C400%2C500%7CRoboto%3A300%2C400%2C500&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='boostrap-css'  href='assets/wp-content/themes/new-york-business/css/bootstrap.css' type='text/css' media='all' />
<link rel='stylesheet' id='new-york-business-style-css'  href='assets/wp-content/themes/easy-storefront/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='assets/wp-content/themes/new-york-business/fonts/font-awesome/css/font-awesome.css' type='text/css' media='all' />
<script type='text/javascript' src='assets/wp-includes/js/jquery/jquery.js'></script>
<script type='text/javascript' src='assets/wp-includes/js/jquery/jquery-migrate.min.js'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://askmee.in/wp-content/themes/new-york-business/js/html5.js?ver=3.7.3'></script>
<![endif]-->
<script type='text/javascript' src='assets/wp-content/themes/new-york-business/js/scrolltop.js'></script>
<link rel='https://api.w.org/' href='http://askmee.in/index.php?rest_route=/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://askmee.in/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://askmee.in/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.4.2" />
<meta name="generator" content="WooCommerce 4.2.2" />
<link rel="canonical" href="index.html" />
<link rel='shortlink' href='index.html' />
<link rel="alternate" type="application/json+oembed" href="http://askmee.in/index.php?rest_route=%2Foembed%2F1.0%2Fembed&#038;url=http%3A%2F%2Faskmee.in%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://askmee.in/index.php?rest_route=%2Foembed%2F1.0%2Fembed&#038;url=http%3A%2F%2Faskmee.in%2F&#038;format=xml" />
		<style type="text/css" id="custom-fonts" >
	.site-header-background {
		background-color:#ffffff;
	}
	h1, h2, h3, h4, h5, h6,
	.start-button,
	.testimonial-title,
	#main_Carousel .slider-title,
	.site-title a,
	.sub-header .title {
		font-family:"Roboto",sans serif;
	}
	html {
		font-family:"Roboto",sans serif;
	}
	.main-navigation {
		font-family:"Roboto",sans serif;
	}
	.site-title, .custom-fonts .testimonial-title {
		font-family:"Roboto",sans serif;
	}
	#main_Carousel .slider-title {
		font-family:"Roboto",sans serif;
	}
			</style>
		<style type="text/css" id="custom-footer-colors" >
	.footer-foreground {}
	.footer-foreground .widget-title, 
	.footer-foreground a, 
	.footer-foreground p, 
	.footer-foreground td,
	.footer-foreground th,
	.footer-foreground caption,
	.footer-foreground li,
	.footer-foreground h1,
	.footer-foreground h2,
	.footer-foreground h3,
	.footer-foreground h4,
	.footer-foreground h5,
	.footer-foreground h6,
	.footer-foreground .site-info a
	{
	  color:#191919;
	}
	.footer-foreground #today {
		font-weight: 600;	
		background-color: #3ba0f4;	
		padding: 5px;
	}
	.footer-foreground a:hover, 
	.footer-foreground a:active {
		color:#ccc ;
	}
		</style>
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style type="text/css" id="custom-background-css">
body.custom-background { background-color: #ffffff; }
</style>
	</head>